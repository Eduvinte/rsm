import React from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import '../styleSheet/About.css';

function About() {
  return (
    <div className='about'>
        <div id='text'>
            <h4>Sobre la Plataforma</h4>
            <p>La aplicación esta desarrollada con ReactJs, estamos consumiendo la API del SII
              que nos esta devolviendo un archivo JSON. Mollit amet culpa culpa consectetur officia duis sit sint nostrud. Sint in veniam amet Lorem sit. Est labore qui esse veniam ea eiusmod amet nostrud quis amet consectetur quis pariatur velit. Veniam aute officia eu consectetur consectetur esse nulla non dolore quis nulla laboris id. Sit laboris aute in magna. Non officia anim ullamco labore ipsum laborum nostrud enim duis voluptate sit. Et do laboris qui tempor fugiat cupidatat elit.
            </p>
        </div>
    </div>
  )
}

export default About