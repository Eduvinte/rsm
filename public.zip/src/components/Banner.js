import React from "react";
import '../styleSheet/Banner.css';



function Banner() {
  return (
    <div id="banner">
      <div id="title-banner">
        <h1>INDICADORES FINANCIEROS</h1>
      </div>
    </div>
  );
}

export default Banner;
